package com.avellaneda.ejemplorecyclerviewjava;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * RecyclerView recicla esos elementos individuales.
 * Cuando un elemento se desplaza fuera de la pantalla, RecyclerView no destruye su vista.
 * En cambio, reutiliza la vista para los elementos nuevos que se desplazaron
 * y ahora se muestran en pantalla.
 * RecyclerView mejora el rendimiento y la capacidad de respuesta de tu app,
 * y reduce el consumo de batería.
 */
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private List<ExamItem> examList;
    private Context context;

    // Constructor
    public MyAdapter(List<ExamItem> examList,Context context) {
        this.context = context;
        this.examList = examList;

    }

    /**
     * Cuando definas tu adaptador, anularás tres métodos clave:
     *
     * onCreateViewHolder(): RecyclerView Llama a este método siempre que necesita crear
     * una ViewHolder nueva.
     * El método crea y, luego, inicializa la ViewHolder y su View asociada,
     * pero no completa el contenido de la vista;
     * aún no se vinculó la ViewHolder con datos específicos.
     *
     * onBindViewHolder(): RecyclerView Llama a este método para asociar una ViewHolder con los datos.
     * El método recupera los datos correspondientes y los usa para completar
     * el diseño del contenedor de vistas. Por ejemplo, si RecyclerView muestra una lista de nombres,
     * el método podría encontrar el nombre apropiado en la lista y completar el widget de TextView
     * del contenedor de vistas.
     *
     * getItemCount(): RecyclerView llama a este método para obtener el tamaño del conjunto de datos.
     * Por ejemplo, en una app de libreta de direcciones, ese tamaño podría ser la cantidad
     * total de direcciones. RecyclerView lo usa para determinar cuándo no hay más elementos
     * que se puedan mostrar.
     *
     */

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // el contexto lo conseguimos con parent.getConext()
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.exam_card, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        ExamItem examItem = examList.get(position);

        holder.examName.setText(examItem.getName());
        holder.examDate.setText(examItem.getDate());
        holder.examMessage.setText(examItem.getMessage());
        holder.examPic.setImageResource(examItem.getImage1());
        holder.examPic2.setImageResource(examItem.getImage2());


        holder.btnMenu.setOnClickListener(v -> {


                PopupMenu popup = new PopupMenu(context, holder.btnMenu);
                popup.inflate(R.menu.menu_item); // tu menú XML

                popup.setOnMenuItemClickListener(menuItem -> {

                    // obtener la posición REAL del ViewHolder
                    int pos = holder.getBindingAdapterPosition();
                    int elemento = menuItem.getItemId();
                    if (pos == RecyclerView.NO_POSITION) {
                        return false;}

                        if(R.id.opcion_editar== elemento) {
                            Toast.makeText(context,
                                    "Editar: " + examList.get(pos).getName(),
                                    Toast.LENGTH_SHORT).show();
                            return true;
                        }
                        if(R.id.opcion_borrar== elemento) {

                            String eliminado = examList.get(pos).getName();
                            examList.remove(pos);        // eliminar del array
                            notifyItemRemoved(pos);   // notificar al RecyclerView

                            Toast.makeText(context,
                                    "Eliminado: " + eliminado,
                                    Toast.LENGTH_SHORT).show();
                            return true;}


                    return false;
                });

                popup.show();
            });
/**
 *
 */
        }



    @Override
    public int getItemCount() {
        return examList.size();
    }

    // ViewHolder class

    /**
     * Un ViewHolder es un “contenedor” que guarda las vistas necesarias para representar un ítem
     * Ayuda a mejorar rendimiento y claridad del código
     * Evita llamadas repetidas a findViewById(), que son costosas.
     * Hace3 el scroll más fluido.
     * Mantiene un patrón ordenado para manejar cada ítem del RecyclerView.
     */
    static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView examName, examDate, examMessage;
        ImageView examPic, examPic2;
        ImageButton btnMenu;

        public MyViewHolder(@NonNull View itemView) {

            super(itemView);

            examName = itemView.findViewById(R.id.examName);
            examDate = itemView.findViewById(R.id.examDate);
            examMessage = itemView.findViewById(R.id.examMessage);
            examPic = itemView.findViewById(R.id.examPic);
            examPic2 = itemView.findViewById(R.id.examPic2);
            btnMenu = itemView.findViewById(R.id.btnMenu);
        }
    }
}