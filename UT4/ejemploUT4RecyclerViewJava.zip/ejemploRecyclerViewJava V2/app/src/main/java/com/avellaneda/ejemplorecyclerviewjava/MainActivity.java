package com.avellaneda.ejemplorecyclerviewjava;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Context context;
    MyAdapter adapter;
    RecyclerView recyclerView;
    List<ExamItem> examList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       examList = DaoItems.getItems();
        context = this;
         adapter = new MyAdapter(examList, context);
         recyclerView = findViewById(R.id.recyclerView);
        /**
         * El administrador de diseño organiza los elementos individuales de tu lista.
         * Puedes usar uno de los administradores de diseño proporcionados por la biblioteca
         * RecyclerView o puedes definir el tuyo.
         * Todos los administradores de diseño se basan en la clase abstracta LayoutManager de la biblioteca.
         */
        // Set LayoutManager
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        /**
         * LinearLayoutManager dispone los elementos en una lista unidimensional.
         * GridLayoutManager dispone los elementos en una cuadrícula bidimensional:
         * Si la cuadrícula está organizada de forma vertical, GridLayoutManager intenta
         * que todos los elementos de cada fila tengan el mismo ancho y la misma altura,
         * pero las filas pueden tener alturas distintas.
         * Si la cuadrícula está organizada de forma horizontal,
         * GridLayoutManager intenta que todos los elementos de cada columna tengan el mismo ancho
         * y la misma altura, pero las columnas pueden tener anchos distintos.
         * StaggeredGridLayoutManager es similar a GridLayoutManager,
         * pero no requiere que los elementos de una fila tengan la misma altura
         * (en cuadrículas verticales) o que los elementos de la misma columna tengan
         * el mismo ancho (en cuadrículas horizontales).
         * El resultado es que los elementos de una fila o columna pueden terminar
         * compensándose entre sí.
         */

        recyclerView.setAdapter(adapter);



    }

    /**
     * Si eliminamos NoActionBar, se mostrará la barra clásica de herramientas aunque es
     * Menos personalizable (color, forma, contenido).
     * No compatible con algunos diseños modernos (Material 3 recomienda Toolbar/MaterialToolbar).
     *
     * <com.google.android.material.appbar.MaterialToolbar
     *     android:id="@+id/toolbar"
     *     android:layout_width="match_parent"
     *     android:layout_height="?attr/actionBarSize"
     *     android:background="?attr/colorPrimary"
     *     app:title="Mi App" />
     * Otra opción es añadir una Toolbar
     * MaterialToolbar toolbar = findViewById(R.id.toolbar);
     * setSupportActionBar(toolbar);
     * Esta opción, permite añadir la barra de herramientas, solamente en las actividades que queramos
     *
     */

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_opcion,menu);
        return true;
    }

public boolean onOptionsItemSelected(MenuItem item){
   // LinearLayout root = findViewById(R.id.rootLayout);
    // View root = findViewById(android.R.id.content);
    // Es un ID especial que Android asigna automáticamente al contenedor raíz de la Activity.
        if(item.getItemId() == R.id.opcion1){
            // TODO crear un activity para añadir elementos

            Intent intent = new Intent(context, AddExamActivity.class);
            addExamLauncher.launch(intent);
           /*
            Toast.makeText(context,
                    "AÑADIR: PENDIENTE DE COMPLETAR " ,
                    Toast.LENGTH_SHORT).show();

            Snackbar.make(findViewById(android.R.id.content), "AÑADIR PENDIENTE DE COMPLETAR", Snackbar.LENGTH_LONG).
                    setAction("AÑADIR", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    }).show();*/
            return true;

        }else if(item.getItemId() == R.id.opcionSalir){
            // Usar flags para limpiar el back stack
            // para flujos de autenticación y para controlar la navegación en procesos cerrados
           /* Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();*/


            finishAffinity();
            // cerrar todas las actividades y salir de la aplicación

            //finish();
            // Cerrar la Activity actual
        }

        return super.onOptionsItemSelected(item);
}
    private final ActivityResultLauncher<Intent> addExamLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if(result.getResultCode() == RESULT_OK) {
                            Intent data = result.getData();
                            if(data != null) {
                                ExamItem newExam = (ExamItem) data.getSerializableExtra("newExam");
                                if(newExam != null) {
                                    examList.add(newExam);
                                    adapter.notifyItemInserted(examList.size() - 1);
                                }
                            }
                        }
                    }
            );


}
