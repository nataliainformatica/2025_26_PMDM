package com.avellaneda.ejemplorecyclerviewjava;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddExamActivity extends AppCompatActivity {

    EditText etName, etDate, etMessage;
    Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_exam);

        etName = findViewById(R.id.etExamName);
        etDate = findViewById(R.id.etExamDate);
        etMessage = findViewById(R.id.etExamMessage);
        btnAdd = findViewById(R.id.btnAddExam);

        btnAdd.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            String message = etMessage.getText().toString().trim();

            if(name.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Name and date are required", Toast.LENGTH_SHORT).show();
                return;
            }

            ExamItem newExam = new ExamItem(name, date, message);

            // Devolver el examen usando Activity Result
            Intent intent = new Intent();
            intent.putExtra("newExam", newExam);
            setResult(RESULT_OK, intent);
            finish();
        });
    }
}
