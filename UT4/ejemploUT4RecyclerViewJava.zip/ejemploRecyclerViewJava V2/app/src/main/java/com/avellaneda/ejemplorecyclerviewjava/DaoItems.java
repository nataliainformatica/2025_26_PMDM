package com.avellaneda.ejemplorecyclerviewjava;

import java.util.ArrayList;
import java.util.List;

public class DaoItems {
    private static List<ExamItem> examList = new ArrayList<>();
    public static void remove(int position){
        examList.remove(position);


    }
    public static List<ExamItem> getItems(){
        // Sample data


        examList.add(new ExamItem("Math Exam", "May 23, 2015",
                "Best of Luck", R.drawable.schedule,
                R.drawable.school));

        examList.add(new ExamItem("Science Exam", "June 10, 2015",
                "Do Well", R.drawable.schedule,
                R.drawable.school));

        examList.add(new ExamItem("History Exam", "July 15, 2015",
                "All the Best", R.drawable.schedule,
                R.drawable.school));

        examList.add(new ExamItem("English Exam", "August 1, 2015",
                "Stay Confident", R.drawable.schedule,
                R.drawable.school));
        examList.add(new ExamItem("English Exam", "August 1, 2015",
                "Stay Confident", R.drawable.schedule,
                R.drawable.school));
        examList.add(new ExamItem("English Exam", "August 1, 2015",
                "Stay Confident", R.drawable.schedule,
                R.drawable.school));
        examList.add(new ExamItem("English Exam", "August 1, 2015",
                "Stay Confident", R.drawable.schedule,
                R.drawable.school));
        examList.add(new ExamItem("English Exam", "August 1, 2015",
                "Stay Confident", R.drawable.schedule,
                R.drawable.school));
        examList.add(new ExamItem("English Exam", "August 1, 2015",
                "Stay Confident", R.drawable.schedule,
                R.drawable.school));
        examList.add(new ExamItem("English Exam", "August 1, 2015",
                "Stay Confident", R.drawable.schedule,
                R.drawable.school));
    return  examList;
    }


    }

